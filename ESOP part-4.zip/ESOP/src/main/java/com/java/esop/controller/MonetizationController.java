package com.java.esop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.esop.appconstant.Appconstant;
import com.java.esop.entity.Exercise;
import com.java.esop.service.MonetizationService;

@RestController
@RequestMapping(value=Appconstant.MONETIZATION_CONTROLLER)
public class MonetizationController {

	@Autowired
	MonetizationService monetizationService;
	
	
	
	@PostMapping(value=Appconstant.SAVE_EXERCISE_OPTION)
	public void saveExerciseOption(@RequestBody Exercise exercise)
	{
	
		monetizationService.saveExerciseOption(exercise);
		
	}
	
}
